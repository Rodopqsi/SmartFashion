package com.ropa.smartfashionecommerce

import retrofit2.Response
import retrofit2.http.*

interface AuthApi {
    @POST("api/auth/token/")
    suspend fun login(@Body body: Map<String, String>): Response<TokenPair>

    @POST("api/auth/token/refresh/")
    fun refresh(@Body body: Map<String, String>): retrofit2.Call<AccessOnly>
}

interface ShopApi {
    @GET("api/products/")
    suspend fun getProducts(@Query("page") page: Int = 1): PageResponse<ProductDto>
}