package com.ropa.smartfashionecommerce

data class TokenPair(val access: String, val refresh: String)
data class AccessOnly(val access: String)
data class PageResponse<T>(val count: Int, val next: String?, val previous: String?, val results: List<T>)
data class ProductDto(val id: Int, val name: String, val price: Double, val image: String?)