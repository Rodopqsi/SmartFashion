
package com.ropa.smartfashionecommerce.catalog

data class Product(
    val name: String,
    val price: String,
    val imageRes: Int
)
